
import { HttpClient, HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';
import { Injectable } from '@angular/core';
import { Config } from './users';
import { Config11 } from '../Interface/users';
import { Config22 } from '../Interface/user-interface';

@Injectable({
  providedIn: 'root'
})
export class UsersService {
  static result6: any;
  static fetchData() {
    throw new Error('Method not implemented.');
  }
  apiUrl = 'https://www.techiediaries.com/api/data.json';
  result6 = "";

  constructor(private httpClient: HttpClient) { }

  fetchData(){
    const abc = this.httpClient.get(this.apiUrl).toPromise();
    const promise = this.httpClient.get(this.apiUrl).toPromise();
    const promise1 = this.httpClient.get(this.apiUrl).toPromise();
    console.log(promise);  
    promise.then((data)=>{
      // console.log("Promise resolved with: " + JSON.stringify(data));
      console.log("Promise resolved with: " + data );
      promise1.then((data)=>{
        this.result6 = "ok";
        console.log("Promise resolved with2: ");
      }).catch((error)=>{

        console.log("Promise rejected with " + JSON.stringify(error));
       // alert("err"+ JSON.stringify(error));
      });

      // alert(JSON.stringify(data));
      // alert("ok");
    }).catch((error)=>{
      console.log("Promise rejected with " + JSON.stringify(error));
     // alert("err"+ JSON.stringify(error));
    });
  }


}
@Injectable()
export class ConfigService {
  constructor(private http: HttpClient) { }
  configUrl = 'assets/config.json';

  getConfig() {
    return this.http.get<Config>(this.configUrl)
      .pipe(
        retry(3), // retry a failed request up to 3 times
        catchError(this.handleError)
      );
  }
  getConfigResponse(): Observable<HttpResponse<Config>> {
    return this.http.get<Config>(
      this.configUrl, { observe: 'response' });
  }
  getConfigResponse1(): Observable<HttpResponse<Config>> {
    return this.http.get<Config11>(
      this.configUrl, { observe: 'response' });
  }
  getConfigResponse2(): Observable<HttpResponse<Config>> {
    return this.http.get<Config22>(
      this.configUrl, { observe: 'response' });
  }
  

  private handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error.message);
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      console.error(
        `Backend returned code ${error.status}, ` +
        `body was: ${error.error}`);
    }
    // return an observable with a user-facing error message
    return throwError(
      'Something bad happened; please try again later.');
  };
}