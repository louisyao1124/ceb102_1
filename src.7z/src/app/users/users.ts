
export class Data {
    constructor( public name: string,  public age: number){
  
    }
  }


export interface Users {
    name: string;
    age: number;
}

export interface IData{
    name: string;
    age: number;
  }

export interface Config {
    heroesUrl: string;
    textfile: string;
}

interface WeatherForecast {
    dateFormatted: string;
    temperatureC: number;
    temperatureF: number;
    summary: string;
  }