export interface Users {
}

export interface Config11 {
    heroesUrl: string;
    textfile: string;
}