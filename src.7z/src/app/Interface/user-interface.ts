export interface UserInterface {
}


export interface Config22 {
    heroesUrl: string;
    textfile: string;
}