﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using bkframe3.Models;
using bkframe3.Services;
using System.Web.Configuration;

namespace bkframe3.Services
{
    public class UsersServices : BasisServices
    {

        public string conn()
        {
          return WebConfigurationManager.ConnectionStrings["UsersEntities"].ConnectionString;
        }

        public List<AspNetUsersList> GetUserLists()
        {
            List<AspNetUsersList> aa = new List<AspNetUsersList>();
            // string abc = WebConfigurationManager.ConnectionStrings["UsersEntities"].ConnectionString;
            //var cnn = new SqlConnection(conn());
            using (SqlConnection connection = new SqlConnection(conn()))
            {
                connection.Open();
                string query = "SELECT Column1 FROM Table1";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            //columnData.Add(reader.GetString(0));
                        }
                    }
                }
            }


            //string a1 = abc;
            return aa;
            //cnn = new SqlConnection(connetionString);
            //cnn = new SqlConnection(connetionString);
            // cnn = new SqlConnection(connetionString);UsersEntities
            // 連線資料說明 https://stackoverflow.com/questions/12024226/how-to-generate-liststring-from-sql-query



        }


    }
}