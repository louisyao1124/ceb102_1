﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using bkframe3.Models;

using System.Web.Configuration;
using System.Collections;
using System.Text;




namespace bkframe3.Services
{
    public class BasisServices
    {
      string abc = WebConfigurationManager.ConnectionStrings["UsersEntities"].ConnectionString;
        //https://aihuadesign.com/2014/05/10/asp-net-web-config-read-connectionstring-database-connection-string/

        //        //ConfigurationManager.ConnectionStrings["ConnDB"];
    }
}