import { Component, OnInit } from '@angular/core';
import { SelectText } from './select-text.model';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  name = 'Angular';
  selectedProp: string = 2;
  selectedText: any = "yellow";
  selectedText2: SelectText;
  arrayList: Array<any> = [];

  hitMe() {
    this.selectedProp = "2";
  }

  ngOnInit() {
    // this.selectedText = new SelectText();    
    this.arrayList.push({ value: 1, text: "First Value" });
    this.arrayList.push({ value: 2, text: "Second Value" });
    this.arrayList.push({ value: 3, text: "Third Value" });
    this.arrayList.push({ value: 4, text: "Fourth Value" });
    this.arrayList.push({ value: 5, text: "Fifth Value" });
  }
}
