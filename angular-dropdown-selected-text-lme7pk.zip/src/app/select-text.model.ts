export class SelectText {
  public text: string;
  constructor(options: any = {}) {
    this.text = options.text || null;
  }
}